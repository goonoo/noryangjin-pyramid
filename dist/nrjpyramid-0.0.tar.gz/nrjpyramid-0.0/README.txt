nrjpyramid README
